package com.arnav.metrics_monitor_consumer_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetricsMonitorConsumerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetricsMonitorConsumerAppApplication.class, args);
	}

}
